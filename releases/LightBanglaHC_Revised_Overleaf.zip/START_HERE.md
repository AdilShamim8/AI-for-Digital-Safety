# Overleaf import and completion

Import this ZIP into a new Overleaf project. Select pdfLaTeX.

- Option A, names the case/competition: set main.tex as main document.
- Option B, uses public-datathon wording: set main_anonymized.tex as main document.

Both compiled PDFs are ten pages, including references. Neither naming option
was selected for the authors. Both are anonymous-author review manuscripts.
Keep author-details.tex inactive during blind review; all authors go in CMT.

This is the completed formatting and author-review revision. Complete visible
TODO-AUTHOR fields and the unperformed nested stacking comparison (or resolve
the narrower scope) before submission. Original source arithmetic remains
unchanged; the new LR comparison and its iteration limits are clearly labeled.

The included class/style/assets are supplied template dependencies. Do not
invent publication metadata. The PDF is the conference upload; this ZIP is
for editing/compiling. Full evidence, datasets, notebooks and archives are
in the separate complete repository ZIP and major-revision report.

Supplement S1 and the stacking protocol are under supplements/.
