# Full revision and submission checklist

Updated 10 October 2026. The paper now audits the supplied updated notebook,
not the older five-fold TinyLinear description. Formatting is complete.
The contribution is dependency and accounting analysis; it is not a new
classifier, verified competition victory, or measured deployment advantage.

| # | Item | Status / required action |
| --- | --- | --- |
| 1 | Canonical notebook | Done: exact updated Drive bytes match attachment. |
| 2 | Source identity | Done: full SHA-256, one cell, 971 lines, execution count one. |
| 3 | Chronology | Corrected: metadata 20 April 2026; not an authenticated timestamp. |
| 4 | Version boundaries | Done: current CV=3, earlier CV=5 TinyLinear, and larger four-class record separated. |
| 5 | Dataset selection | Done: original 2026 ZIP extraction used; loose larger files preserved separately. |
| 6 | Shapes/schema | Done: train 47,817×3; test 11,955×2; expected columns. |
| 7 | Label meanings | Done: supplied description maps Explicit/Subtle/Neutral to 0/1/2. |
| 8 | Supports | Done: 23,756 /18,163 /5,898 match raw CSVs and updated output. |
| 9 | Corpus scope | Done: 59,772 total; documented Bangla/English/Banglish, no measured proportions. |
| 10 | IDs | Done: smaller IDs unique/disjoint; old CSV matches test/sample order; larger IDs repeat. |
| 11 | Exact text repetition | Done: 621 train,54 test repeats;254 distinct shared texts; impact unmeasured. |
| 12 | Near duplicates/groups | Unperformed: inspect semantic duplicates, users/threads/time before future evaluation. |
| 13 | Annotation manual | Missing: definitions/procedure/agreement beyond label names. |
| 14 | Data permissions | Partial: supplied DOCX lists CC BY-NC-ND4.0; original terms and larger extra-row permissions unverified. |
| 15 | Ethics/consent | Missing: authors must state documented basis; public collection alone proves neither. |
| 16 | Feature dimensions | Corrected: four branches 230,105; LGB 230,125 including 20 numerical features. |
| 17 | Routing | Corrected: CNB 130,000 character columns; LGB numerical features; other base models TF-IDF only. |
| 18 | Lexical inventory | Corrected: 73 explicit strings, 25 subtle entries; distinct substring presence. |
| 19 | Cue interpretation | Done: markers are rules, not validated intent/sarcasm/language measurements. |
| 20 | Configurations | Corrected: six base candidates, CV=3, calibration CV=2, LGB stopping; explicit settings listed. |
| 21 | Meta inputs | Corrected: 18 probabilities, three Meta-LR fits; active final ensemble member. |
| 22 | Selected path | Corrected: weighted seven-member ensemble; no current TinyLinear head. |
| 23 | Score table | Corrected: current pooled/fold scores preserved; weighted 0.5314 vs LR_C3 0.5221. |
| 24 | Performance gap | Done: 0.0093 descriptive; no significant or causal superiority claimed. |
| 25 | Confusion matrix | Done: original figure transcribed; F1 0.5314177985 and accuracy 0.5803166238 reconstructed. |
| 26 | OOF rows | Missing: preserve IDs, labels, probabilities and fold indices for pairing/replay. |
| 27 | Global TF-IDF | Done: validation covariates enter representation before folds; effect unmeasured. |
| 28 | Global weights | Done: evaluation labels affect class/sample weights before folds. |
| 29 | Meta dependency | Done: nonnested features carry meta validation labels through other base fits. |
| 30 | Early stopping | Done: LGB assessment labels select rounds; different loss does not isolate reporting. |
| 31 | Ensemble weights | Done: pooled F1² determines seven combination weights. |
| 32 | Threshold selection | Done: 900 pairs per ensemble, baseline omitted; four variants compared on same labels. |
| 33 | OOF/test distinction | Done: held-out single-fit outputs differ from test fold averages. |
| 34 | Dependence | Corrected: CV=3 fitting pairs share 1/3 corpus or 1/2 fitting subset; no naive interval. |
| 35 | Identity module | Corrected: separately profiled zero-state operation absent from prediction path. |
| 36 | THOP evidence | Done: zero initializes/falls back; printed zero alone does not prove successful profiling. |
| 37 | Fractional exports | Critical: 0.183 derives from F1/2.9; fractions are not measured parameter counts. |
| 38 | Structural subtotal | Corrected: six base LR fits 4,141,908 scalars; three Meta-LR fits 171; no full total inferred. |
| 39 | Official scorer | Missing: original equation image/log base/scoring code; supplied descriptions conflict. |
| 40 | Count boundary | Missing: confirm official designated component/full pipeline rule and supported classical-model accounting. |
| 41 | Rank | Unverified: historical values external; no first-place or achieved score 2.9 claim. |
| 42 | Updated CSV outputs | Missing: output prints 6,414/4,401/1,140 and NOP 0.183; actual generated CSVs absent. Old NOP 39 file stays legacy. |
| 43 | Zero export filename | Done: guard skips zero save despite summary recommending it. |
| 44 | Timing | Corrected: main training sections 150.5min; metadata 152.4min contradict 25–35min summary. |
| 45 | Runtime | Missing: package versions/device/fitted calibration defaults; GPU metadata conflict retained. |
| 46 | Serialization | Missing: fitted models/OOF arrays not saved by source; no fresh-process equivalence or resource benchmark. |
| 47 | Generalization claims | Conditional: protected holdout/fully nested procedure, fair baselines and paired outputs necessary for stronger claims. |
| 48 | Feature/calibration claims | Conditional: ablations, proper scores and reliability diagnostics needed for corresponding claims. |
| 49 | Efficiency/deployment claims | Conditional: serialize/reload full predictor; measure bytes/RAM/latency/energy; contextual/subgroup error work. |
| 50 | Authors | Submission blocker: Shamim Hasan first confirmed; supply two exact names/order, affiliations and emails. |
| 51 | Author approval/disclosures | Submission blocker: all approve revision; confirm corresponding author, funding/interests/ethics/permissions and AI disclosure. |
| 52 | Literature and wording | Done: focused existing references retained; primary LightGBM reference added; markers replaced with explicit limits. |
| 53 | Format/package | Done: supplied IJCVSP class/style unchanged;10 pages including references; PDF/source/complete archive provided. |
| 54 | CMT | Pending: anonymous PDF; accurate authors entered before initial submission; deadline 20 October 2026; verify closing time and retain receipt. |

Recommended order: confirm authors/disclosures; obtain authoritative scorer and
count rule; approve the audit framing; rebuild after any edits; upload the
anonymous PDF through the existing CMT record or create one only if none exists.
The missing updated CSV is an export-verification limitation; do not invent its
labels or a parameter count. A narrow audit does not require every prospective
experiment above, provided stronger claims are not made.

Official rules: https://cennser.org/ICIEV/paper-submission.html

Dates: https://cennser.org/ICIEV/important-dates.html

Evidence: `audit/verification.json`, `audit/EVIDENCE_LEDGER.md`,
`audit/manifest.json`, `audit/paper_changes.diff`.
